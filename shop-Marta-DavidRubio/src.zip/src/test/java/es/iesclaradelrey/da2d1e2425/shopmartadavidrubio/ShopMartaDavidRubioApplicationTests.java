package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopMartaDavidRubioApplicationTests {

	@Test
	void contextLoads() {
	}

}
