package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.exceptions;

public class CategoryNotFoundException extends RuntimeException {
    public CategoryNotFoundException(String message) {
        super(message);
    }
}
