package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.exceptions.admin;

public class CategoryNotEmptyException extends RuntimeException {
    public CategoryNotEmptyException(String message) {
        super(message);
    }
}
