package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.exceptions.admin;

public class ProductAlreadyExistsException extends RuntimeException {
    public ProductAlreadyExistsException(String message) {
        super(message);
    }
}
