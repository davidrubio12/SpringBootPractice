package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.exceptions;

public class ProductNotFoundException extends RuntimeException {
    public ProductNotFoundException(String message) {

        super(message);
    }
}
