package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.filters;

import es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.Utils.ProblemDetailsUtils;
import es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.services.JwtService;
import io.jsonwebtoken.JwtException;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.lang.NonNull;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;
    private final UserDetailsService userDetailsService;

    private static final String AUTH_HEADER = "Authorization";
    private static final String BEARER_PREFIX = "Bearer ";

    // Añadimos varias rutas protegidas
    private static final AntPathRequestMatcher[] protectedMatchers = {
            new AntPathRequestMatcher("/home/app/api/app/v1/cart/**"),
            new AntPathRequestMatcher("/home/app/api/app/v1/product/**")
    };

    public JwtAuthenticationFilter(JwtService jwtService, UserDetailsService userDetailsService) {
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    @NonNull HttpServletResponse response,
                                    @NonNull FilterChain filterChain) throws ServletException, IOException {

        boolean isProtected = false;
        for (AntPathRequestMatcher matcher : protectedMatchers) {
            if (matcher.matches(request)) {
                isProtected = true;
                break;
            }
        }

        if (isProtected) {
            try {
                String authHeader = request.getHeader(AUTH_HEADER);
                if (authHeader == null || !authHeader.startsWith(BEARER_PREFIX)) {
                    throw new JwtException("Authorization header missing or incorrect.");
                }

                String token = authHeader.substring(BEARER_PREFIX.length());
                jwtService.validateAccessToken(token);
                String username = jwtService.extractUsername(token);

                UserDetails userDetails = userDetailsService.loadUserByUsername(username);
                Authentication authentication = new UsernamePasswordAuthenticationToken(
                        userDetails, null, userDetails.getAuthorities()
                );
                SecurityContextHolder.getContext().setAuthentication(authentication);

            } catch (Exception e) {
                ProblemDetailsUtils.writeUnauthorized(response, request,
                        "Error validating access token: " + e.getMessage());
                return;
            }
        }

        filterChain.doFilter(request, response);
    }
}
