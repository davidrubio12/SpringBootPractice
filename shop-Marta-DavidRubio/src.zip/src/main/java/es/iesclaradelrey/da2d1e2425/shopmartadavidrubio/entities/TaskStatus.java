package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.entities;

public enum TaskStatus {
    PENDING, IN_PROGRESS, COMPLETED
}
