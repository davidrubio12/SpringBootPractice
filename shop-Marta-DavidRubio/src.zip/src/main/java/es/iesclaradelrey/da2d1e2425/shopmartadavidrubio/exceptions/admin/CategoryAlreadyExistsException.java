package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.exceptions.admin;

public class CategoryAlreadyExistsException extends RuntimeException {
    public CategoryAlreadyExistsException(String message) {
        super(message);
    }
}
