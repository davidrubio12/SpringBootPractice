package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.services;

public enum JwtTokenType {
    ACCESS,REFRESH;
}
