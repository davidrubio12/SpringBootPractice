package es.iesclaradelrey.da2d1e2425.shopmartadavidrubio.exceptions;

public class NotEnoughQuantityException extends RuntimeException {
    public NotEnoughQuantityException(String message) {
        super(message);

    }
}
